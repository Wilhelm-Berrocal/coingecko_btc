import io
import pandas as pd
from datetime import date, datetime
if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def transform(coin_price_df):
    """
    Template code for a transformer block.

    Add more parameters to this function if this block has multiple parent blocks.
    There should be one parameter for each output variable from each parent block.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    # Specify your transformation logic here
    coin_price_df['utc_epoch'] = pd.to_numeric(coin_price_df['utc_epoch'], errors='coerce')
    coin_price_df['usd_price'] = pd.to_numeric(coin_price_df['usd_price'], errors='coerce')
    coin_price_df.dropna(how='any', inplace=True)
    
    coin_price_df['utc_datetime'] = pd.to_datetime(coin_price_df['utc_epoch'], unit='ms').dt.date
    coin_price_df.drop(['utc_epoch'], axis = 1, inplace = True)
    
    coin_price_df = coin_price_df.groupby(['utc_datetime']).mean().reset_index()
    coin_price_df['usd_price'] = coin_price_df['usd_price'].round(2)

    return coin_price_df


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
