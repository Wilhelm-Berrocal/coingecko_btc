import io
import pandas as pd
import requests
if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Template for loading data from API
    """
    ini_timestamp = 1641016800
    end_timestamp = 1648706400

    url = f'https://api.coingecko.com/api/v3/coins/bitcoin/market_chart/range?vs_currency=usd&from={ini_timestamp}&to={end_timestamp}&precision=2'
    response = requests.get(url)
    coin_historic_prices_json = response.json()
    coin_price_df = pd.DataFrame(coin_historic_prices_json['prices'], columns =['utc_epoch', 'usd_price'])

    return coin_price_df


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
